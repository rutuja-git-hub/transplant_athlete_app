import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Video, Users, Brain, Clock, Star, DollarSign } from "lucide-react";

const therapyOptions = [
  {
    id: 1,
    type: "Professional",
    title: "Individual Therapy",
    therapist: "Dr. Sarah Chen",
    specialty: "Transplant Psychology",
    duration: "50 minutes",
    price: "$120",
    rating: 4.9,
    availability: "Available Today",
    description: "One-on-one therapy sessions focused on post-transplant emotional challenges and athletic identity.",
    features: ["CBT Approach", "Trauma-Informed", "Insurance Accepted"]
  },
  {
    id: 2,
    type: "Group",
    title: "Athlete Support Group",
    therapist: "Led by Maria Rodriguez, LCSW",
    specialty: "Group Facilitation",
    duration: "90 minutes",
    price: "$45",
    rating: 4.8,
    availability: "Weekly - Thursdays 6PM",
    description: "Weekly group sessions for transplant athletes sharing experiences and coping strategies.",
    features: ["Peer Support", "Guided Discussion", "Weekly Check-ins"]
  },
  {
    id: 3,
    type: "Student",
    title: "Student-Led Support",
    therapist: "Alex Thompson (Graduate Student)",
    specialty: "Peer Counseling",
    duration: "45 minutes",
    price: "Free",
    rating: 4.7,
    availability: "Flexible Schedule",
    description: "Affordable sessions with supervised graduate students in mental health programs.",
    features: ["Cost-Effective", "Peer Understanding", "Flexible Hours"]
  }
];

const TherapySection = () => {
  return (
    <section id="therapy" className="py-20 bg-muted/30">
      <div className="container px-4">
        <div className="text-center space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">Therapy Options</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose from professional therapy, group sessions, or student-led support based on your needs and budget.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {therapyOptions.map((option) => (
            <Card key={option.id} className="shadow-card hover:shadow-glow transition-all duration-300 border-primary-light/20">
              <CardHeader className="space-y-4">
                <div className="flex items-center justify-between">
                  <Badge 
                    variant={option.type === 'Professional' ? 'default' : option.type === 'Group' ? 'secondary' : 'outline'}
                    className="text-xs"
                  >
                    {option.type}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{option.rating}</span>
                  </div>
                </div>
                
                <div>
                  <CardTitle className="text-xl mb-2">{option.title}</CardTitle>
                  <p className="text-sm text-muted-foreground">{option.therapist}</p>
                  <p className="text-xs text-primary font-medium">{option.specialty}</p>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <p className="text-sm text-muted-foreground">{option.description}</p>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{option.duration}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{option.price}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Features:</p>
                  <div className="flex flex-wrap gap-2">
                    {option.features.map((feature, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <p className="text-sm text-success font-medium mb-3">{option.availability}</p>
                  <div className="space-y-2">
                    <Button className="w-full bg-gradient-primary hover:shadow-glow">
                      {option.type === 'Group' ? 
                        <><Users className="h-4 w-4 mr-2" />Join Group</> : 
                        <><Video className="h-4 w-4 mr-2" />Book Session</>
                      }
                    </Button>
                    <Button variant="outline" size="sm" className="w-full">
                      View Profile
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline">
            <Brain className="h-5 w-5 mr-2" />
            View All Therapists
          </Button>
        </div>
      </div>
    </section>
  );
};

export default TherapySection;