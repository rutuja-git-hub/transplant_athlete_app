import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Video, FileText, Headphones, Download, Play, Clock, Star } from "lucide-react";

const resources = [
  {
    id: 1,
    type: "Guide",
    title: "Post-Transplant Mental Health Guide",
    description: "Comprehensive guide covering emotional challenges, coping strategies, and mental health resources for transplant athletes.",
    duration: "15 min read",
    rating: 4.9,
    downloads: 1200,
    icon: BookOpen,
    category: "Essential Reading",
    isFree: true
  },
  {
    id: 2,
    type: "Video",
    title: "Managing Anxiety After Surgery",
    description: "Expert-led video series on understanding and managing post-surgical anxiety and fear of re-injury.",
    duration: "45 min",
    rating: 4.8,
    downloads: 890,
    icon: Video,
    category: "Video Series",
    isFree: true
  },
  {
    id: 3,
    type: "Meditation",
    title: "Healing Meditation Series",
    description: "Guided meditations specifically designed for physical and emotional healing during transplant recovery.",
    duration: "20 min sessions",
    rating: 4.9,
    downloads: 2100,
    icon: Headphones,
    category: "Audio Content",
    isFree: false
  },
  {
    id: 4,
    type: "Workbook",
    title: "Athletic Identity Reconstruction",
    description: "Interactive workbook helping athletes rebuild their sense of self and purpose after transplant surgery.",
    duration: "Self-paced",
    rating: 4.7,
    downloads: 650,
    icon: FileText,
    category: "Interactive",
    isFree: false
  },
  {
    id: 5,
    type: "Article",
    title: "Building Resilience: A Transplant Journey",
    description: "Evidence-based strategies for developing psychological resilience throughout the transplant and recovery process.",
    duration: "8 min read",
    rating: 4.8,
    downloads: 1500,
    icon: BookOpen,
    category: "Research",
    isFree: true
  },
  {
    id: 6,
    type: "Webinar",
    title: "Family Support & Communication",
    description: "Live webinar series addressing how families can best support transplant athletes' mental health journey.",
    duration: "60 min",
    rating: 4.9,
    downloads: 780,
    icon: Video,
    category: "Live Sessions",
    isFree: true
  }
];

const ResourcesSection = () => {
  return (
    <section id="resources" className="py-20 bg-muted/30">
      <div className="container px-4">
        <div className="text-center space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">Mental Health Resources</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Access evidence-based resources, guides, and tools designed specifically for transplant athletes' mental health journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource) => {
            const IconComponent = resource.icon;
            return (
              <Card key={resource.id} className="shadow-card hover:shadow-glow transition-all duration-300 border-primary-light/20">
                <CardHeader className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="p-3 rounded-lg bg-gradient-primary">
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      <Badge variant={resource.isFree ? "default" : "secondary"} className="text-xs">
                        {resource.isFree ? "Free" : "Premium"}
                      </Badge>
                      <div className="flex items-center space-x-1">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs">{resource.rating}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Badge variant="outline" className="text-xs">{resource.category}</Badge>
                    <CardTitle className="text-lg leading-tight">{resource.title}</CardTitle>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <p className="text-sm text-muted-foreground">{resource.description}</p>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{resource.duration}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Download className="h-4 w-4 text-muted-foreground" />
                      <span>{resource.downloads}</span>
                    </div>
                  </div>

                  <div className="flex space-x-3">
                    <Button className="flex-1 bg-gradient-primary hover:shadow-glow">
                      {resource.type === 'Video' || resource.type === 'Webinar' ? (
                        <><Play className="h-4 w-4 mr-2" />Watch</>
                      ) : (
                        <><Download className="h-4 w-4 mr-2" />Access</>
                      )}
                    </Button>
                    <Button variant="outline" size="sm">
                      Preview
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-12 space-y-4">
          <Button size="lg" variant="outline">
            <BookOpen className="h-5 w-5 mr-2" />
            Browse All Resources
          </Button>
          <div className="flex justify-center space-x-6 text-sm text-muted-foreground">
            <span>📚 50+ Guides</span>
            <span>🎥 25+ Videos</span>
            <span>🧘 20+ Meditations</span>
            <span>📊 15+ Workbooks</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResourcesSection;