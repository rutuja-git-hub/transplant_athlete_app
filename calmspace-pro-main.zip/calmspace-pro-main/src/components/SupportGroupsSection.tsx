import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageCircle, Users, Calendar, Lock, Globe } from "lucide-react";

const supportGroups = [
  {
    id: 1,
    name: "Post-Transplant Warriors",
    type: "Open Group",
    members: 24,
    nextSession: "Today, 7:00 PM",
    facilitator: {
      name: "Dr. Jennifer Lee",
      avatar: "/api/placeholder/40/40",
      credentials: "LMFT, Transplant Specialist"
    },
    description: "A safe space for athletes navigating life after transplant surgery, focusing on identity reconstruction and emotional healing.",
    topics: ["Identity & Self-Image", "Recovery Anxiety", "Athletic Performance"],
    isPrivate: false
  },
  {
    id: 2,
    name: "Peer Support Circle",
    type: "Peer-Led",
    members: 18,
    nextSession: "Tomorrow, 6:30 PM",
    facilitator: {
      name: "Marcus Johnson",
      avatar: "/api/placeholder/40/40",
      credentials: "Heart Transplant Athlete, 3 years"
    },
    description: "Fellow transplant athletes sharing experiences, challenges, and victories in a peer-to-peer environment.",
    topics: ["Peer Support", "Success Stories", "Daily Challenges"],
    isPrivate: true
  },
  {
    id: 3,
    name: "Family & Caregivers",
    type: "Mixed Group",
    members: 31,
    nextSession: "Wednesday, 5:00 PM",
    facilitator: {
      name: "Sarah Mitchell",
      avatar: "/api/placeholder/40/40",
      credentials: "LCSW, Family Therapy"
    },
    description: "Support for family members and caregivers of transplant athletes, addressing relationship dynamics and support strategies.",
    topics: ["Family Dynamics", "Caregiver Stress", "Communication"],
    isPrivate: false
  },
  {
    id: 4,
    name: "Mindfulness & Wellness",
    type: "Guided Practice",
    members: 45,
    nextSession: "Friday, 8:00 AM",
    facilitator: {
      name: "Dr. Lisa Chen",
      avatar: "/api/placeholder/40/40",
      credentials: "Mindfulness-Based Therapist"
    },
    description: "Guided meditation, breathing exercises, and mindfulness practices specifically designed for transplant recovery.",
    topics: ["Meditation", "Stress Reduction", "Body Awareness"],
    isPrivate: false
  }
];

const SupportGroupsSection = () => {
  return (
    <section id="support" className="py-20">
      <div className="container px-4">
        <div className="text-center space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">Support Groups</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Join communities of understanding, where shared experiences become pathways to healing and growth.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {supportGroups.map((group) => (
            <Card key={group.id} className="shadow-card hover:shadow-glow transition-all duration-300 border-primary-light/20">
              <CardHeader className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <CardTitle className="text-xl">{group.name}</CardTitle>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary">{group.type}</Badge>
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        {group.isPrivate ? (
                          <><Lock className="h-3 w-3" />Private</>
                        ) : (
                          <><Globe className="h-3 w-3" />Open</>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-1 text-sm">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>{group.members} members</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={group.facilitator.avatar} />
                    <AvatarFallback>{group.facilitator.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-sm">{group.facilitator.name}</p>
                    <p className="text-xs text-muted-foreground">{group.facilitator.credentials}</p>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <p className="text-sm text-muted-foreground">{group.description}</p>

                <div className="space-y-3">
                  <p className="text-sm font-medium">Focus Areas:</p>
                  <div className="flex flex-wrap gap-2">
                    {group.topics.map((topic, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-gradient-card rounded-lg border">
                  <div className="flex items-center space-x-2 mb-2">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">Next Session</span>
                  </div>
                  <p className="text-sm text-primary font-medium">{group.nextSession}</p>
                </div>

                <div className="flex space-x-3">
                  <Button className="flex-1 bg-gradient-primary hover:shadow-glow">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Join Group
                  </Button>
                  <Button variant="outline" size="sm">
                    Learn More
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12 space-y-4">
          <Button size="lg" variant="outline">
            <Users className="h-5 w-5 mr-2" />
            Browse All Groups
          </Button>
          <p className="text-sm text-muted-foreground">
            Can't find the right group? <a href="#" className="text-primary hover:underline">Request a new group</a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default SupportGroupsSection;