import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Description */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-white/10 flex items-center justify-center">
                <Heart className="h-5 w-5 text-white" />
              </div>
              <span className="font-semibold text-lg">TransplantHeart</span>
            </div>
            <p className="text-primary-foreground/80 text-sm leading-relaxed">
              Empowering transplant athletes with specialized mental health support, 
              connecting communities, and fostering healing through understanding.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Linkedin className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold">Quick Links</h3>
            <nav className="space-y-2 text-sm">
              <a href="#therapy" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Therapy Sessions
              </a>
              <a href="#support" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Support Groups
              </a>
              <a href="#resources" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Resources
              </a>
              <a href="#about" className="block text-primary-foreground/80 hover:text-white transition-colors">
                About Us
              </a>
              <a href="#contact" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Contact
              </a>
            </nav>
          </div>

          {/* Support */}
          <div className="space-y-4">
            <h3 className="font-semibold">Support</h3>
            <nav className="space-y-2 text-sm">
              <a href="#" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Crisis Support
              </a>
              <a href="#" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Help Center
              </a>
              <a href="#" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Terms of Service
              </a>
              <a href="#" className="block text-primary-foreground/80 hover:text-white transition-colors">
                Community Guidelines
              </a>
            </nav>
          </div>

          {/* Contact & Newsletter */}
          <div className="space-y-4">
            <h3 className="font-semibold">Stay Connected</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span className="text-primary-foreground/80">24/7 Crisis Line: (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span className="text-primary-foreground/80">support@transplantheart.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span className="text-primary-foreground/80">National Service Available</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm text-primary-foreground/80">Subscribe for updates:</p>
              <div className="flex space-x-2">
                <Input 
                  placeholder="Your email" 
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
                <Button variant="secondary" size="sm">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-primary-foreground/80">
              © 2024 TransplantHeart. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 text-sm text-primary-foreground/80">
              <span>🔒 HIPAA Compliant</span>
              <span>⚡ 24/7 Crisis Support</span>
              <span>🌍 Nationwide Coverage</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;