import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import TherapySection from "@/components/TherapySection";
import SupportGroupsSection from "@/components/SupportGroupsSection";
import ResourcesSection from "@/components/ResourcesSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <TherapySection />
        <SupportGroupsSection />
        <ResourcesSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
